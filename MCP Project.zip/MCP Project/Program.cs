﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ModelContextProtocol;
using System.Net.Http.Headers;




var builder = Host.CreateEmptyApplicationBuilder(null);

builder.Services.AddMcpServer()
    .WithStdioServerTransport() //Connects AI client to this app
    .WithToolsFromAssembly(); //Automatically discovers custom c# tools

builder.Services.AddSingleton(_ =>
{
    var client = new HttpClient() { BaseAddress = new Uri("http://localhost:5072") };
    client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue("Employee-tool", "1.0"));
    return client;
});

var app = builder.Build();

await app.RunAsync();