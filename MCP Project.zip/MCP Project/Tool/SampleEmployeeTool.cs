﻿using MCP_Project.Helper;
using ModelContextProtocol.Server;
using System.ComponentModel;
using System.Net.Http.Json;

namespace MCP_Project.Tool
{
    [McpServerToolType]
    public static class SampleEmployeeTool
    {
        [McpServerTool, Description("Get all the employee details")]
        public static async Task<string> GetallEmployees(HttpClient httpClient)
        {
            //test im going to check
            using var jsonDocument = await httpClient.ReadJsonDocumentAsync($"/api/Employee");
            var jsonElement = jsonDocument.RootElement;
            return jsonElement.GetRawText();
        }
        [McpServerTool, Description("Adds a new employee record. Returns the API's confirmation message.")]
        public static async Task<string> AddAnEmployee(
        HttpClient httpClient,
        [Description("Employee ID, e.g. 102")] int id,
        [Description("Full name of the employee")] string name,
        [Description("Department the employee belongs to, e.g. Development")] string department,
        [Description("True if the employee is currently serving, false otherwise")] bool isStillServing)
        {
            var employee = new
            {
                ID = id,
                Name = name,
                Department = department,
                IsStillserving = isStillServing
            };

            using var response = await httpClient.PostAsJsonAsync("/api/Employee", employee);
            response.EnsureSuccessStatusCode();

            return await response.Content.ReadAsStringAsync(); // "Record created"
        }
    }
}
